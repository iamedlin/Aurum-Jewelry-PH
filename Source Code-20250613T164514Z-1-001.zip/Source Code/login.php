<?php
session_start();

if (isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $conn = new mysqli("localhost", "u663344503_221024", "Database_3", "u663344503_users");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM user_info WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {
            $_SESSION["userID"] = $user["userID"];
            $_SESSION["name"] = $user["name"];
            $_SESSION["email"] = $user["email"];
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "User not found.";
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aurum Jewelry PH</title>
    <style>
      
        body { 
            font-family: Arial, sans-serif; 
            background-color: #FDA4BA; 
            padding: 50px; 
        }
        header {
             background-color: #FDA4BA;
             color: rgb(19, 15, 15);
             text-align: center;
            padding: 30px 0 10px 0;
        }
        header h1 {
            margin: 0;
            font-size: 2em;
         }

        
        .container { 
            max-width: 800px; 
            margin: auto; 
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0,0,0,0.1); 
            margin-top: 30px; 
            display: flex; 
        }

        .left-section {
            flex: 1;
            padding: 80px;
            border-right: 1px solid #ddd; 
            margin-left: 30px;
        }

        .right-section {
            flex: 2; 
            padding: 20px;
            margin-left: 30px;
            margin-top: 50px;
        }

        input { 
            width: calc(100% - 20px); 
            padding: 10px; 
            margin: 10px 0; 
            border: 1px solid #ddd; 
            border-radius: 5px; 
            box-sizing: border-box; 
        }

        button { 
            width: calc(100% - 20px); 
            padding: 10px; 
            background-color: #F26B8A; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            margin-top: 10px; 
            box-sizing: border-box; 
        }

        button:hover { 
            background-color: #ff8da1; 
        }

        p { 
            text-align: center; 
        }

        .logo { 
            display: block;  
            margin: 0 auto 20px auto; 
            max-width: 175px; 
            height: 175px; 
            border-radius: 50%; 
            object-fit: cover; 
        }
    </style>
</head>
<header>
 <h1>Aurum Jewelry PH</h1>
  </header>
<body>


    <div class="container">
        <div class="left-section">
            <h2>Welcome Back!</h2>
            <p>If you don't have an account, please sign up.</p>
            <button onclick="window.location.href='signup.php';">Sign Up</button>
            <button onclick="window.location.href='index.php';">Cancel</button>
        </div>
        
        <div class="right-section">
            <h1>Log In</h1>
 <form method="POST">
  <input type="text" name="email" placeholder="Email" required />
  <input type="password" name="password" placeholder="Password" required />
  <button type="submit">Log In</button>
</form>
  <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
        </div>
    </div>

</body>
</html>
